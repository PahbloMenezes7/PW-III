<?php
session_start();
if (!isset($_SESSION['usuario'])) {
    header("Location: login.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Painel</title>
    <style>
        <?php include 'style.css'; ?>
    </style>
</head>
<body>
    <div class="form-container">
        <h2>Bem-vindo, <?php echo $_SESSION['usuario']; ?>!</h2>
        <a href="usuarios.php">Gerenciar usuários</a>
        <br><br>
        <a href="logout.php">Sair</a>
    </div>
</body>
</html>
