<?php
require 'Usuario.class.php';
$usuario = new Usuario();

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $nome  = $_POST['nome'] ?? '';
    $email = $_POST['email'] ?? '';
    $senha = $_POST['senha'] ?? '';

    if ($usuario->chkUser($email)) {
        echo "<script>alert('Usuário já cadastrado!'); window.location.href='cadastrar.php';</script>";
    } else {
        $usuario->cadastrar($nome, $email, $senha);
        echo "<script>alert('Cadastro realizado com sucesso!'); window.location.href='login.php';</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Cadastrar</title>
    <style>
        <?php include 'style.css'; ?>
    </style>
</head>
<body>
    <div class="form-container">
        <h2>Cadastro</h2>
        <form method="POST">
            <input type="text" name="nome" placeholder="Nome" required>
            <input type="email" name="email" placeholder="E-mail" required>
            <input type="password" name="senha" placeholder="Senha" required>
            <input type="submit" value="Cadastrar">
        </form>
        <a href="login.php">Já tenho login</a>
    </div>
</body>
</html>
