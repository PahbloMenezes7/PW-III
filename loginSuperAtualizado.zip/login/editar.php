<?php
require 'Usuario.class.php';
$usuario = new Usuario();

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $usuario->alterar($_POST['id'], $_POST['nome'], $_POST['email'], $_POST['senha']);
    echo "<script>alert('Atualizado com sucesso!'); window.location.href='usuarios.php';</script>";
}

$dados = $usuario->buscar($_GET['id']);
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Editar Usuário</title>
    <style>
        <?php include 'style.css'; ?>
    </style>
</head>
<body>
    <div class="form-container">
        <h2>Editar Usuário</h2>
        <form method="POST">
            <input type="hidden" name="id" value="<?= $dados['id'] ?>">
            <input type="text" name="nome" value="<?= $dados['nome'] ?>" required>
            <input type="email" name="email" value="<?= $dados['email'] ?>" required>
            <input type="password" name="senha" placeholder="Nova senha" required>
            <input type="submit" value="Atualizar">
        </form>
    </div>
</body>
</html>
