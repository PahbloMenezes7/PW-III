<?php

//if($_POST['nome']){
    $nome  = $_POST['nome'];
    $email = $_POST['email'];
    $senha = $_POST['senha'];

    echo "Nome $nome - Email $email - Senha $senha";
//}else{
//    echo"nao veio";
//}