<?php
require 'Usuario.class.php';
$usuario = new Usuario();

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $email = $_POST['email'] ?? '';
    $senha = $_POST['senha'] ?? '';

    $logado = $usuario->chkPass($email, $senha);
    if ($logado) {
        session_start();
        $_SESSION['usuario'] = $logado['nome'];
        header("Location: painel.php");
        exit;
    } else {
        echo "<script>alert('Usuário ou senha incorretos'); window.location.href='login.php';</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Login</title>
    <style>
        <?php include 'style.css'; ?>
    </style>
</head>
<body>
    <div class="form-container">
        <h2>Login</h2>
        <form method="POST">
            <input type="email" name="email" placeholder="E-mail" required>
            <input type="password" name="senha" placeholder="Senha" required>
            <input type="submit" value="Entrar">
        </form>
        <a href="cadastro.php">Não possui conta? Cadastre-se</a>
    </div>
</body>
</html>
