<?php
require 'Usuario.class.php';
$usuario = new Usuario();

if (isset($_GET['excluir'])) {
    $usuario->apagar($_GET['excluir']);
    header("Location: usuarios.php");
}

$lista = $usuario->listarTodos();
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Usuários</title>
    <style>
        <?php include 'style.css'; ?>
        table {
            width: 100%;
            border-collapse: collapse;
        }
        th, td {
            border: 1px solid #555;
            padding: 10px;
            text-align: center;
        }
    </style>
</head>
<body>
    <div class="form-container">
        <h2>Usuários Cadastrados</h2>
        <a href="cadastro.php">Inserir novo usuário</a>
        <br><br>
        <table>
            <tr>
                <th>ID</th><th>Nome</th><th>Ações</th>
            </tr>
            <?php foreach ($lista as $item): ?>
            <tr>
                <td><?= $item['id'] ?></td>
                <td><?= $item['nome'] ?></td>
                <td>
                    <a href="editar.php?id=<?= $item['id'] ?>">Editar</a> | 
                    <a href="usuarios.php?excluir=<?= $item['id'] ?>" onclick="return confirm('Deseja excluir?')">Excluir</a>
                </td>
            </tr>
            <?php endforeach ?>
        </table>
    </div>
</body>
</html>
